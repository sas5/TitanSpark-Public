// Cache for headers
const headerCache = new Map();

// 1. Listen to all outgoing network requests and cache their headers
chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
        if (details.type === "main_frame" || details.type === "sub_frame" || 
            details.type === "xmlhttprequest" || details.type === "other") {
            
            let headers = {};
            for (let h of details.requestHeaders) {
                headers[h.name.toLowerCase()] = h.value;
            }
            
            headerCache.set(details.url, { headers: headers, timestamp: Date.now() });
            
            setTimeout(() => {
                for (let [key, value] of headerCache.entries()) {
                    if (Date.now() - value.timestamp > 30000) {
                        headerCache.delete(key);
                    }
                }
            }, 30000);
        }
        return { requestHeaders: details.requestHeaders };
    },
    { urls: ["<all_urls>"] },
    ["requestHeaders", "extraHeaders"] 
);

// ==========================================
// 2. THE TRAFFIC CONTROLLER (Queue System)
// ==========================================
let downloadQueue = [];
let isProcessingQueue = false;

async function processQueue() {
    // If already processing or queue is empty, do nothing
    if (isProcessingQueue || downloadQueue.length === 0) return;
    isProcessingQueue = true;

    while (downloadQueue.length > 0) {
        const payload = downloadQueue.shift();
        console.log("Dispatching queued download:", payload.url);

        // Send to Mode 1 (Delivery Boy). We use sendNativeMessage because 
        // our C# app is designed to fire and instantly exit!
        chrome.runtime.sendNativeMessage("com.titanspark.broker", payload, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Broker Error:", chrome.runtime.lastError.message);
            } else {
                console.log("TitanSpark Bridge Success:", response);
            }
        });

        // THE MAGIC: Wait 1 second before processing the next download in the queue.
        // This prevents Chrome from launching 50 C# executables at the same time,
        // and stops Windows Shell from throwing the 0x80040904 Rate Limit Error.
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    isProcessingQueue = false;
}

// 3. Intercept downloads
chrome.downloads.onCreated.addListener(async (downloadItem) => {

    // ---> THE NEW FILTER <---
    // Ignore web pages and internal Chrome background data
    if (downloadItem.mime === "text/html" || 
        downloadItem.url.startsWith("blob:") || 
        downloadItem.url.startsWith("chrome-extension://") ||
        downloadItem.url.startsWith("file://") ||          // NEW: Ignore local drag-and-drops
        downloadItem.url.endsWith(".crx") ||               // NEW: Ignore extension URLs
        downloadItem.filename.endsWith(".crx")) {          // NEW: Ignore extension files
        
        console.log("TitanSpark Ignored file:", downloadItem.url);
        return; // Let Chrome handle it normally (allows installation)
    }
    
    console.log("Download detected by Extension:", downloadItem.url);
    
    try {
        await chrome.downloads.cancel(downloadItem.id);
        
        let cached = headerCache.get(downloadItem.url);
        let reqHeaders = cached ? cached.headers : {};
        
        if (!reqHeaders["cookie"]) {
            try {
                const cookies = await chrome.cookies.getAll({ url: downloadItem.url });
                if (cookies.length > 0) {
                    reqHeaders["cookie"] = cookies.map(c => `${c.name}=${c.value}`).join('; ');
                }
            } catch (e) { console.error("Failed to get cookies:", e); }
        }
        
        if (!reqHeaders["user-agent"]) reqHeaders["user-agent"] = navigator.userAgent;
        if (downloadItem.referrer && !reqHeaders["referer"]) reqHeaders["referer"] = downloadItem.referrer;
        
        const payload = {
            url: downloadItem.url,
            filename: downloadItem.filename,
            headers: reqHeaders,
            timestamp: Date.now()
        };
        
        // Push the payload to the queue instead of firing instantly
        downloadQueue.push(payload);
        processQueue(); // Start the line moving!
        
    } catch (error) {
        console.error("Error handling download:", error);
    }
});

// Keep service worker alive
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === "keepAlive") {
        setTimeout(() => port.disconnect(), 250000);
    }
});